import { retrieveEvidence } from '../../src/services/ragEngine.js';

/**
 * RAG Service layer for server handling query execution
 */
export function executeQuery({
  query = '',
  productName = '',
  ingredients = '',
  intendedUse = '',
  description = '',
  concern = 'patent',
  jurisdiction = 'India',
  language = 'en',
  classification = ''
} = {}) {
  // Execute RAG engine retrieval over verified corpus
  return retrieveEvidence({
    query,
    productName,
    ingredients,
    intendedUse,
    description,
    concern,
    jurisdiction
  });
}
