import React, { useState } from 'react';
import { X, UserCheck, ShieldAlert, CheckCircle2, Calendar, Phone, Mail } from 'lucide-react';

export default function FacilitatorModal({ isOpen, onClose, currentProduct }) {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: 'Dr. Aarav Sharma',
    email: 'aarav@ayush-innovations.in',
    phone: '+91 98765 43210',
    preferredDate: '2026-09-10',
    notes: currentProduct ? `Seeking consultation regarding ${currentProduct.name} IP and TKDL compliance.` : 'Need guidance on Ayurvedic product patent & regulatory approval.'
  });

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#FAF7F0] border border-[#E0D8C8] rounded-3xl w-full max-w-lg shadow-2xl p-6 relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#5F5F5F] hover:text-[#2B2B2B] bg-white rounded-full p-1.5 shadow-xs"
        >
          <X className="w-5 h-5" />
        </button>

        {!submitted ? (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-[#1F5C3D] flex items-center justify-center text-white">
                <UserCheck className="w-6 h-6 text-[#8FBC94]" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#1F5C3D]">Consult AYUSH IP Facilitator</h3>
                <p className="text-xs text-[#5F5F5F]">Connect with certified Indian Patent Attorneys & AYUSH Experts</p>
              </div>
            </div>

            <p className="text-xs text-[#5F5F5F] bg-[#EAF3EC] border border-[#C8E0CE] p-3 rounded-xl mb-5">
              ⚖️ <strong>Expert Facilitation Scheme:</strong> Under Ministry of AYUSH & DPIIT initiatives, registered startups and traditional practitioners receive subsidized IP filing support.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#2B2B2B] mb-1">Your Full Name / Business</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#D5CEBF] rounded-xl text-xs font-medium text-[#2B2B2B] focus:outline-none focus:border-[#1F5C3D]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#2B2B2B] mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#D5CEBF] rounded-xl text-xs font-medium text-[#2B2B2B] focus:outline-none focus:border-[#1F5C3D]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#2B2B2B] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-white border border-[#D5CEBF] rounded-xl text-xs font-medium text-[#2B2B2B] focus:outline-none focus:border-[#1F5C3D]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2B2B2B] mb-1">Preferred Consultation Date</label>
                <input
                  type="date"
                  required
                  value={formData.preferredDate}
                  onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#D5CEBF] rounded-xl text-xs font-medium text-[#2B2B2B] focus:outline-none focus:border-[#1F5C3D]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#2B2B2B] mb-1">Product Details / Specific Query</label>
                <textarea
                  rows="3"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#D5CEBF] rounded-xl text-xs font-medium text-[#2B2B2B] focus:outline-none focus:border-[#1F5C3D]"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#1F5C3D] hover:bg-[#16452D] text-white font-bold text-sm rounded-xl shadow-md transition"
              >
                Schedule Free Consultation Session
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 bg-[#EAF3EC] text-[#1F5C3D] rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-extrabold text-[#1F5C3D]">Consultation Scheduled!</h3>
            <p className="text-xs text-[#5F5F5F] max-w-sm mx-auto">
              Your inquiry has been assigned to <strong>AYUSH Facilitation Cell (Ref #FC-2026-891)</strong>. An IP Facilitator will reach out via email within 24 business hours.
            </p>
            <button
              onClick={() => { setSubmitted(false); onClose(); }}
              className="px-6 py-2.5 bg-[#1F5C3D] text-white text-xs font-bold rounded-xl shadow-sm"
            >
              Close Window
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

