import React, { useState } from 'react';
import { Languages, Search, UserCheck, Sparkles, ChevronDown } from 'lucide-react';
import { TRANSLATIONS } from '../data/mockData';

export default function Header({ lang, setLang, activeScreen, onOpenFacilitator }) {
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;

  const screenTitles = {
    home: t.navHome,
    input: 'Input Capture & Analysis',
    qna: 'Product Classification Q&A',
    result: 'Classification Summary & Prior Art',
    concern: 'Select IP Concern',
    answer: 'AI Guidance & RAG Sources',
    analyses: t.navAnalyses,
    reports: t.navReports,
    knowledge: t.navKnowledge,
    guide: t.navGuide,
    about: t.navAbout
  };

  return (
    <header className="bg-white/70 backdrop-blur-md border-b border-[#E0D8C8] px-8 py-4 flex items-center justify-between sticky top-0 z-20 shadow-xs no-print">
      {/* Active Screen Title & Breadcrumb */}
      <div className="flex items-center gap-3">
        <h2 className="text-lg font-bold text-[#2B2B2B]">
          {screenTitles[activeScreen] || 'IP-SAKTI SAHAYAK'}
        </h2>
        <span className="text-xs bg-[#EAF3EC] text-[#1F5C3D] px-2.5 py-1 rounded-full font-semibold border border-[#C8E0CE]">
          SIH MVP Live
        </span>
      </div>

      {/* Right Tools: Language Selector & Facilitator Booking Button */}
      <div className="flex items-center gap-4">
        {/* Language Dropdown */}
        <div className="relative">
          <button
            onClick={() => setLangMenuOpen(!langMenuOpen)}
            className="flex items-center gap-2 px-3.5 py-2 bg-[#FAF7F0] border border-[#D5CEBF] rounded-xl text-xs font-bold text-[#1F5C3D] hover:bg-[#F3EDE0] transition"
          >
            <Languages className="w-4 h-4 text-[#1F5C3D]" />
            <span>{lang === 'hi' ? 'हिंदी 🌐' : 'English 🌐'}</span>
            <ChevronDown className="w-3.5 h-3.5 text-[#5F5F5F]" />
          </button>

          {langMenuOpen && (
            <div className="absolute right-0 mt-1 w-36 bg-white border border-[#E0D8C8] rounded-xl shadow-lg py-1 z-50 text-xs font-medium">
              <button
                onClick={() => { setLang('en'); setLangMenuOpen(false); }}
                className={`w-full text-left px-3 py-2 hover:bg-[#EAF3EC] ${lang === 'en' ? 'text-[#1F5C3D] font-bold' : 'text-[#2B2B2B]'}`}
              >
                English (EN)
              </button>
              <button
                onClick={() => { setLang('hi'); setLangMenuOpen(false); }}
                className={`w-full text-left px-3 py-2 hover:bg-[#EAF3EC] ${lang === 'hi' ? 'text-[#1F5C3D] font-bold' : 'text-[#2B2B2B]'}`}
              >
                हिंदी (Hindi)
              </button>
            </div>
          )}
        </div>

        {/* IP Facilitator Consultation Button */}
        <button
          onClick={onOpenFacilitator}
          className="flex items-center gap-2 px-4 py-2 bg-[#1F5C3D] hover:bg-[#16452D] text-white text-xs font-bold rounded-xl shadow-sm transition"
        >
          <UserCheck className="w-4 h-4 text-[#8FBC94]" />
          <span>{t.consultFacilitator}</span>
        </button>
      </div>
    </header>
  );
}

