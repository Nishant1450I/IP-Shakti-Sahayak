import React, { useState } from 'react';
import { 
  Home, 
  FileText, 
  Bookmark, 
  BookOpen, 
  Globe, 
  Info, 
  ShieldCheck, 
  ChevronDown,
  Sparkles
} from 'lucide-react';
import { TRANSLATIONS } from '../data/mockData';

export default function Sidebar({ activeScreen, setActiveScreen, lang, setLang, jurisdiction = 'India', setJurisdiction }) {
  const [countryOpen, setCountryOpen] = useState(false);
  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;
  
  const isInternational = (jurisdiction || '').toLowerCase().includes('international');
  const selectedLabel = isInternational ? 'International (WIPO / FDA)' : 'India (AYUSH / IPO)';

  const navItems = [
    { id: 'home', label: t.navHome, icon: Home },
    { id: 'analyses', label: t.navAnalyses, icon: FileText },
    { id: 'reports', label: t.navReports, icon: Bookmark },
    { id: 'knowledge', label: t.navKnowledge, icon: BookOpen },
    { id: 'guide', label: t.navGuide, icon: Globe },
    { id: 'about', label: t.navAbout, icon: Info }
  ];

  return (
    <aside className="w-72 bg-white/80 backdrop-blur-md border-r border-[#E0D8C8] flex flex-col justify-between h-screen sticky top-0 z-30 p-5 shadow-sm no-print">
      <div>
        {/* Brand Logo & Emblem */}
        <div className="flex items-center gap-3 mb-8 cursor-pointer" onClick={() => setActiveScreen('home')}>
          <div className="w-11 h-11 rounded-2xl bg-[#1F5C3D] flex items-center justify-center text-white shadow-md">
            {/* SVG Botanical / Shield Motif Emblem from Stitch */}
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 2L4 6V12C4 17.5 7.4 21.8 12 23C16.6 21.8 20 17.5 20 12V6L12 2Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M12 6C12 6 9 9 9 12C9 14.5 10.5 16 12 16C13.5 16 15 14.5 15 12C15 9 12 6 12 6Z" fill="#8FBC94"/>
              <path d="M12 12V18" stroke="#1F5C3D" strokeWidth="1.5" strokeLinecap="round"/>
            </svg>
          </div>
          <div>
            <h1 className="font-extrabold text-xl tracking-tight text-[#1F5C3D] leading-none">
              IP-SAKTI <span className="text-[#8FBC94] font-bold">SAHAYAK</span>
            </h1>
            <p className="text-[11px] text-[#5F5F5F] font-medium tracking-wide uppercase mt-1">Ayurveda IP & Reg Co-Pilot</p>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="space-y-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveScreen(item.id)}
                className={`w-full flex items-center gap-3.5 px-4 py-3 rounded-xl font-medium text-sm transition-all duration-200 ${
                  isActive
                    ? 'bg-[#1F5C3D] text-white shadow-md font-semibold'
                    : 'text-[#2B2B2B] hover:bg-[#EAF3EC] hover:text-[#1F5C3D]'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-[#5F5F5F]'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Footer Section: Country Selector + Disclaimer Strip */}
      <div className="space-y-4 pt-4 border-t border-[#E8E2D5]">
        {/* Country Selector Dropdown */}
        <div className="relative">
          <button
            onClick={() => setCountryOpen(!countryOpen)}
            className="w-full flex items-center justify-between px-3.5 py-2.5 bg-[#FAF7F0] border border-[#D5CEBF] rounded-xl text-xs font-semibold text-[#2B2B2B] hover:bg-[#F3EDE0] transition"
          >
            <div className="flex items-center gap-2">
              <span className="text-base">{isInternational ? '🌐' : '🇮🇳'}</span>
              <span>{selectedLabel}</span>
            </div>
            <ChevronDown className="w-4 h-4 text-[#5F5F5F]" />
          </button>

          {countryOpen && (
            <div className="absolute bottom-full mb-1 w-full bg-white border border-[#E0D8C8] rounded-xl shadow-lg py-1 z-40 text-xs">
              <button
                onClick={() => { setJurisdiction && setJurisdiction('India'); setCountryOpen(false); }}
                className={`w-full text-left px-3 py-2 hover:bg-[#EAF3EC] flex items-center gap-2 ${!isInternational ? 'text-[#1F5C3D] font-semibold' : 'text-[#2B2B2B]'}`}
              >
                <span>🇮🇳</span> India (AYUSH / IPO / TKDL)
              </button>
              <button
                onClick={() => { setJurisdiction && setJurisdiction('International'); setCountryOpen(false); }}
                className={`w-full text-left px-3 py-2 hover:bg-[#EAF3EC] flex items-center gap-2 ${isInternational ? 'text-[#1F5C3D] font-semibold' : 'text-[#2B2B2B]'}`}
              >
                <span>🌐</span> International (WIPO / FDA)
              </button>
            </div>
          )}
        </div>

        {/* Educational Trust Disclaimer */}
        <div className="p-3 bg-[#EAF3EC] border border-[#C8E0CE] rounded-xl flex items-start gap-2.5 text-[11px] text-[#1F5C3D] leading-snug">
          <ShieldCheck className="w-4 h-4 text-[#1F5C3D] shrink-0 mt-0.5" />
          <span>{t.disclaimer}</span>
        </div>
      </div>
    </aside>
  );
}

