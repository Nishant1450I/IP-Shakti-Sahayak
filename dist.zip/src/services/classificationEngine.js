// Preliminary Ayurvedic Product Classification Engine

export function classifyProduct(answers = {}, inputData = {}) {
  const { q1, q2, q3, q4, q5 } = answers;
  const productName = (inputData.productName || '').toLowerCase();
  const intendedUse = (inputData.intendedUse || '').toLowerCase();

  let category = 'Proprietary medicine';
  let attributes = [];
  let isClassical = false;
  let tkdlPriorArtMatch = false;

  // Decision Logic
  if (q3 && q3.includes('Traditional / Classical Name') && q5 && q5.includes('Yes')) {
    category = 'Classical Ayurvedic medicine';
    isClassical = true;
    tkdlPriorArtMatch = true;
    attributes.push('Classical Text Formula', 'Public Domain Prior Art');
  } else if (intendedUse.includes('hair') || intendedUse.includes('skin') || intendedUse.includes('cosmetic') || (q2 && q2.includes('Topical') && productName.includes('taila'))) {
    category = 'Cosmetic';
    attributes.push('Topical Herbal Application', 'Cosmetic Rules 2020 Scope');
  } else if (intendedUse.includes('food') || intendedUse.includes('nutraceutical') || intendedUse.includes('immunity drop') || productName.includes('arka')) {
    category = 'Food/nutraceutical';
    attributes.push('Oral Health Supplement', 'FSSAI Nutraceutical Scope');
  } else if (q5 && q5.includes('No, novel proprietary formulation')) {
    category = 'New/non-classical formulation';
    attributes.push('Proprietary R&D Blend', 'Form 25D Licensing Required');
  } else {
    category = 'Proprietary medicine';
    attributes.push('Ayurvedic Proprietary Drug', 'Drugs & Cosmetics Act Sec 3(h)');
  }

  if (productName.includes('turmeric') || productName.includes('haridra') || productName.includes('neem') || productName.includes('aloe')) {
    tkdlPriorArtMatch = true;
    attributes.push('TKDL Ingredient Match');
  }

  return {
    category,
    isClassical,
    tkdlPriorArtMatch,
    attributes,
    disclaimer: 'Preliminary automated classification for educational decision support. Official legal classification is determined by the State AYUSH Licensing Authority and Patent Office.'
  };
}

