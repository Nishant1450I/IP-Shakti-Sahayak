import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import FacilitatorModal from './components/FacilitatorModal';
import ReportDetailModal from './components/ReportDetailModal';

// Screens
import HomeScreen from './screens/HomeScreen';
import InputCaptureScreen from './screens/InputCaptureScreen';
import ClassificationQAScreen from './screens/ClassificationQAScreen';
import ClassificationResultScreen from './screens/ClassificationResultScreen';
import ConcernSelectionScreen from './screens/ConcernSelectionScreen';
import AIAnswerScreen from './screens/AIAnswerScreen';
import MyAnalysesScreen from './screens/MyAnalysesScreen';
import SavedReportsScreen from './screens/SavedReportsScreen';
import KnowledgeBaseScreen from './screens/KnowledgeBaseScreen';
import CountryGuideScreen from './screens/CountryGuideScreen';
import AboutScreen from './screens/AboutScreen';

import { INITIAL_PAST_ANALYSES } from './data/mockData';

export default function App() {
  const [activeScreen, setActiveScreen] = useState('home');
  const [lang, setLang] = useState('en');
  const [inputMode, setInputMode] = useState('details');
  const [jurisdiction, setJurisdiction] = useState('India');

  // Core Flow Input State
  const [inputData, setInputData] = useState({
    productName: 'Herbal Wound Care Formulation',
    ingredients: 'Turmeric, Neem, Aloe Vera',
    intendedUse: 'Topical wound care',
    description: 'Herbal wound care formulation combining Turmeric, Neem, and Aloe Vera in a topical ointment base.'
  });
  const [qaAnswers, setQaAnswers] = useState(null);
  const [selectedConcern, setSelectedConcern] = useState('patent');

  // Saved Analyses & Reports
  const [analysesList, setAnalysesList] = useState(INITIAL_PAST_ANALYSES);
  const [savedReports, setSavedReports] = useState([
    {
      id: 'rep-901',
      date: new Date().toISOString().split('T')[0],
      productName: 'Herbal Wound Care Formulation',
      category: 'Ayurvedic Proprietary Medicine',
      primaryConcern: 'PATENT (SECTION 3p)',
      confidenceScore: 92
    }
  ]);

  // Modals
  const [facilitatorOpen, setFacilitatorOpen] = useState(false);
  const [reportModalData, setReportModalData] = useState(null);

  // Flow Triggers
  const handleSelectInputModeFromHome = (mode) => {
    setInputMode(mode);
    setActiveScreen('input');
  };

  const handleInputSubmitted = (data) => {
    setInputData(data);
    setActiveScreen('qna');
  };

  const handleQACompleted = (answers) => {
    setQaAnswers(answers);
    setActiveScreen('result');
  };

  const handleProceedToConcerns = () => {
    setActiveScreen('concern');
  };

  const handleSelectConcern = (concernId) => {
    setSelectedConcern(concernId);
    setActiveScreen('answer');
  };

  const handleSaveReport = (newReport) => {
    setSavedReports([newReport, ...savedReports]);
    setAnalysesList([
      {
        id: newReport.id,
        date: newReport.date,
        productName: newReport.productName,
        category: newReport.category,
        primaryConcern: newReport.primaryConcern,
        confidenceScore: newReport.confidenceScore,
        status: 'Saved to Dossier'
      },
      ...analysesList
    ]);
  };

  const handleReopenAnalysis = (analysis) => {
    setInputData({
      productName: analysis.productName,
      ingredients: 'Turmeric, Neem, Aloe Vera',
      intendedUse: 'Topical wound care',
      description: 'Herbal wound care formulation'
    });
    setSelectedConcern('patent');
    setActiveScreen('answer');
  };

  return (
    <div className="flex min-h-screen bg-[#FAF7F0] text-[#2B2B2B]">
      {/* Persistent Sidebar */}
      <Sidebar
        activeScreen={activeScreen}
        setActiveScreen={setActiveScreen}
        lang={lang}
        setLang={setLang}
        jurisdiction={jurisdiction}
        setJurisdiction={setJurisdiction}
      />

      {/* Main Workspace */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          lang={lang}
          setLang={setLang}
          activeScreen={activeScreen}
          onOpenFacilitator={() => setFacilitatorOpen(true)}
        />

        <main className="flex-1 p-6 lg:p-10 max-w-7xl mx-auto w-full">
          {activeScreen === 'home' && (
            <HomeScreen
              onSelectInputMode={handleSelectInputModeFromHome}
              setActiveScreen={setActiveScreen}
              lang={lang}
            />
          )}

          {activeScreen === 'input' && (
            <InputCaptureScreen
              defaultMode={inputMode}
              onSubmitInput={handleInputSubmitted}
            />
          )}

          {activeScreen === 'qna' && (
            <ClassificationQAScreen
              inputData={inputData}
              onCompleteQA={handleQACompleted}
            />
          )}

          {activeScreen === 'result' && (
            <ClassificationResultScreen
              inputData={inputData}
              qaAnswers={qaAnswers}
              onProceedToConcerns={handleProceedToConcerns}
            />
          )}

          {activeScreen === 'concern' && (
            <ConcernSelectionScreen
              onSelectConcern={handleSelectConcern}
            />
          )}

          {activeScreen === 'answer' && (
            <AIAnswerScreen
              inputData={inputData}
              selectedConcern={selectedConcern}
              jurisdiction={jurisdiction}
              onOpenFacilitator={() => setFacilitatorOpen(true)}
              onSaveReport={handleSaveReport}
              onDownloadPdf={(inp, concernKey, ragRes) => setReportModalData({
                id: `rep-${Date.now()}`,
                date: new Date().toISOString().split('T')[0],
                productName: inp?.productName || 'Ayurvedic Product',
                category: 'Ayurvedic Proprietary Medicine',
                primaryConcern: (concernKey || 'patent').toUpperCase(),
                confidenceScore: ragRes.confidenceScore
              })}
              onBackToConcerns={() => setActiveScreen('concern')}
              lang={lang}
            />
          )}

          {activeScreen === 'analyses' && (
            <MyAnalysesScreen
              analysesList={analysesList}
              onReopenAnalysis={handleReopenAnalysis}
              lang={lang}
            />
          )}

          {activeScreen === 'reports' && (
            <SavedReportsScreen
              savedReports={savedReports}
              onOpenReportModal={(report) => setReportModalData(report)}
              onDownloadPdf={(report) => setReportModalData(report)}
              lang={lang}
            />
          )}

          {activeScreen === 'knowledge' && (
            <KnowledgeBaseScreen lang={lang} />
          )}

          {activeScreen === 'guide' && (
            <CountryGuideScreen lang={lang} />
          )}

          {activeScreen === 'about' && (
            <AboutScreen
              onOpenFacilitator={() => setFacilitatorOpen(true)}
              lang={lang}
            />
          )}
        </main>
      </div>

      {/* Global Modals */}
      <FacilitatorModal
        isOpen={facilitatorOpen}
        onClose={() => setFacilitatorOpen(false)}
        currentProduct={inputData}
      />

      <ReportDetailModal
        report={reportModalData}
        onClose={() => setReportModalData(null)}
      />
    </div>
  );
}
