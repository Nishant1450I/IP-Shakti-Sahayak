import React, { useState } from 'react';
import { BookOpen, Search, Filter, ExternalLink, Sparkles, X, ShieldCheck } from 'lucide-react';
import { KNOWLEDGE_BASE_DOCS, TRANSLATIONS } from '../data/mockData';

export default function KnowledgeBaseScreen({ lang }) {
  const t = TRANSLATIONS[lang] || TRANSLATIONS.en;
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedDocModal, setSelectedDocModal] = useState(null);

  const categories = ['All', 'Patent Law', 'Trademark Law', 'GI Protection', 'Access & Benefit Sharing (ABS)', 'AYUSH Regulatory', 'Prior Art Database', 'Classical Texts'];

  const filteredDocs = KNOWLEDGE_BASE_DOCS.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) || doc.summary.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'All' || doc.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      {/* Banner */}
      <div className="bg-[#1F5C3D] text-white rounded-3xl p-6 lg:p-8 shadow-md space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#8FBC94]/20 border border-[#8FBC94]/30 text-[#8FBC94] text-xs font-bold rounded-full">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Screen 9 — Authoritative RAG Corpus</span>
        </div>
        <h2 className="text-2xl font-extrabold">{t.navKnowledge}</h2>
        <p className="text-xs text-[#8FBC94] max-w-2xl">
          Search and inspect official Indian statutes, IP regulations, AYUSH notifications, and classical Ayurvedic pharmacopoeial references.
        </p>

        {/* Search Input */}
        <div className="pt-2">
          <div className="relative max-w-xl">
            <Search className="w-4 h-4 text-[#5F5F5F] absolute left-4 top-3.5" />
            <input
              type="text"
              placeholder="Search legal statutes, sections, TKDL codes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-white text-[#2B2B2B] rounded-2xl text-xs font-semibold focus:outline-none shadow-xs"
            />
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition ${
              selectedCategory === cat
                ? 'bg-[#1F5C3D] text-white shadow-xs'
                : 'bg-white border border-[#D5CEBF] text-[#5F5F5F] hover:bg-[#FAF7F0]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Document Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredDocs.map((doc) => (
          <div
            key={doc.id}
            onClick={() => setSelectedDocModal(doc)}
            className="bg-white border border-[#E0D8C8] hover:border-[#1F5C3D] rounded-3xl p-6 shadow-xs hover:shadow-md transition cursor-pointer space-y-4 flex flex-col justify-between group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase bg-[#EAF3EC] text-[#1F5C3D] px-2.5 py-1 rounded-md">
                  {doc.category}
                </span>
                <span className="text-[11px] font-mono text-[#5F5F5F]">{doc.type}</span>
              </div>

              <h3 className="text-base font-extrabold text-[#2B2B2B] group-hover:text-[#1F5C3D] transition">
                {doc.title}
              </h3>
              <p className="text-xs text-[#5F5F5F] leading-relaxed line-clamp-3">{doc.summary}</p>
            </div>

            <div className="pt-3 border-t border-[#E8E2D5] flex items-center justify-between text-xs font-bold text-[#1F5C3D]">
              <span>Authority: {doc.authority}</span>
              <ExternalLink className="w-4 h-4" />
            </div>
          </div>
        ))}
      </div>

      {/* Document Viewer Modal */}
      {selectedDocModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#FAF7F0] border border-[#E0D8C8] rounded-3xl w-full max-w-xl shadow-2xl p-6 lg:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between border-b border-[#E8E2D5] pb-4">
              <div>
                <span className="text-[10px] font-black uppercase bg-[#EAF3EC] text-[#1F5C3D] px-2.5 py-1 rounded-md">
                  {selectedDocModal.category}
                </span>
                <h3 className="text-xl font-extrabold text-[#1F5C3D] mt-2">{selectedDocModal.title}</h3>
                <p className="text-xs text-[#5F5F5F]">{selectedDocModal.authority} ({selectedDocModal.year})</p>
              </div>
              <button
                onClick={() => setSelectedDocModal(null)}
                className="bg-white text-[#5F5F5F] hover:text-[#2B2B2B] rounded-full p-2 shadow-xs"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase text-[#2B2B2B]">Summary Overview</h4>
              <p className="text-xs text-[#2B2B2B] leading-relaxed bg-white p-4 border border-[#E0D8C8] rounded-2xl">
                {selectedDocModal.summary}
              </p>
            </div>

            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase text-[#1F5C3D]">Key Cited Sections & Provisions</h4>
              <div className="space-y-2">
                {selectedDocModal.keyClauses.map((clause, idx) => (
                  <div key={idx} className="p-3 bg-[#EAF3EC] border border-[#C8E0CE] rounded-xl text-xs font-bold text-[#1F5C3D] flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#1F5C3D] shrink-0" />
                    <span>{clause}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedDocModal(null)}
                className="px-6 py-2.5 bg-[#1F5C3D] text-white text-xs font-bold rounded-xl shadow-xs"
              >
                Close Document
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

